gcc *.c utils/*.c packet/*.c events/*.c enet/*.c tlse/tlse.c md5/*.c -lpthread -o proxy -std=c11
